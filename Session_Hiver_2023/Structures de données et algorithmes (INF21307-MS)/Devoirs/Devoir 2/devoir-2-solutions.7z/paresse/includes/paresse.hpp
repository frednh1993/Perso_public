#ifndef __MODULE_PARESSE__
#define __MODULE_PARESSE__

#include <stdexcept>
#include <vector>

////////////////////////////////////////
//
// template avec type générique T
//
// Cette implémentation minimale fait de la
// pseudo-paresse: on ne contournera pas les
// mécanismes de constructeurs/destructeurs
//
//
// 
//
//
template <typename T>
class paresse
 {
  private:

      // je reprend à peu près les noms de la STL
      //
      // Aucune vérification des bornes n'est faite (aussi à la STL)
      //
      size_t capacity; // combien d'éléments au total (taille du tableau)
      size_t nb_items; // combien d'éléments actifs

      std::vector<bool> bitmap;
      std::vector<T> array;

      ////////////////////////////////////////
      bool zero_right(size_t i,size_t & r) const
       {
        while ((i<capacity) && (bitmap[i])) i++;

        r=i; // si invalide, alors r==capacity 
        return (r<capacity); // succès si on arrête avant capacity
       }

      ////////////////////////////////////////
      void shift_right(size_t first, size_t last)
       {
        // on copie à reculons pour
        // s'éviter des copies
        for (size_t i=last;i>first;i--)
         {
          bitmap[i]=bitmap[i-1];
          array[i]=array[i-1];
         }
        
        bitmap[first]=false;
       }

  public:

      ////////////////////////////////////////
      //
      // dit si une case est occupée ou pas
      //
      bool is_occupied(size_t i) const { return bitmap[i]; }

      ////////////////////////////////////////
      //
      // operator[] readonly pour const
      // 
      const T & operator[](size_t i) const
       {
        if (bitmap[i])
         return array[i];
        else
         throw std::out_of_range("case vide");
       }

      ////////////////////////////////////////
      //
      // operator read/write
      //
      // Ici, le problème, c'est que le langage
      // ne permet pas de savoir si c'est en lecture
      // non-const ou en écriture!
      //
      T & operator[](size_t i)
       {
        if (bitmap[i]==false)
         {
          nb_items++;
          bitmap[i]=true;
         }
        return array[i];
       }

      ////////////////////////////////////////
      //
      // libère la case i
      //
      void free(size_t i)
       {
        if (bitmap[i])
         {
          bitmap[i]=false;
          nb_items--;
         }
        else
         throw std::out_of_range("pas d'items dans cette case!");
       }

      ///////////////////////////////////////
      //
      // insère à i
      //
      void insert(size_t i, const T & v)
       {
        // si i est occupé
        if (bitmap[i])
         {
          // ...et qu'on peut tasser
          size_t r;
          if (zero_right(i,r))
           shift_right(i,r);
          else
           // un item tomberait en bas!
           throw std::out_of_range("tableau plein (à droite)!");
         }

        bitmap[i]=true;
        array[i]=v;
        nb_items++;
       }

      ////////////////////////////////////////
      //
      // supprime à i (si on ne tasse rien,
      // c'est juste free(i)
      //
      void remove(size_t i) { free(i); }

      size_t nb() const { return nb_items; }
      size_t size() const { return capacity; }

  paresse(size_t n)
   : capacity(n),
     nb_items(0),
     bitmap(n), // réserve n bits
     array(n)  // réserve n items
  {
   // les constructeurs par défaut des T
   // sont quand même appelés quand on crée
   // le array avec n T dedans.
  }

  ~paresse()
   {
    // ici: tous les destructeurs automagiques.
   }
 };


#endif
 // __MODULE_PARESSE__
