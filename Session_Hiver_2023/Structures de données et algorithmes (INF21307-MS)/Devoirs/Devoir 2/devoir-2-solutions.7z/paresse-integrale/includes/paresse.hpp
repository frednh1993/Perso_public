#ifndef __MODULE_PARESSE__
#define __MODULE_PARESSE__

#include <stdexcept>
#include <vector>

////////////////////////////////////////
//
// template avec type générique T
//
// Cette implémentation utilise la paresse
// intégrale et utilise les mécanismes de
// constructeurs/destructeurs
//
//
template <typename T>
class paresse
 {
  private:

      // je reprend à peu près les noms de la STL
      //
      // Aucune vérification des bornes n'est faite (aussi à la STL)
      //
      size_t capacity; // combien d'éléments au total (taille du tableau)
      size_t nb_items; // combien d'éléments actifs

      std::vector<bool> bitmap;
      T * array;

      ////////////////////////////////////////
      bool zero_right(size_t i,size_t & r) const
       {
        while ((i<capacity) && (bitmap[i])) i++;

        r=i; // si invalide, alors r==capacity 
        return (r<capacity); // succès si on arrête avant capacity
       }

      ////////////////////////////////////////
      void shift_right(size_t first, size_t last)
       {
        // on copie à reculons pour
        // s'éviter des copies, et on
        // vérifie si les objets sont
        // initialisés ou non
        //
        for (size_t i=last;i>first;i--)
         {
          bitmap[i]=bitmap[i-1];
          array[i]=array[i-1];
         }
        
        bitmap[first]=false;
        //array[i].~T(); // destructeur dans insert
       }

  public:

      ////////////////////////////////////////
      //
      // dit si une case est occupée ou pas
      //
      bool is_occupied(size_t i) const { return bitmap[i]; }

      ////////////////////////////////////////
      //
      // operator[] readonly pour const
      // 
      const T & operator[](size_t i) const
       {
        if (bitmap[i])
         return array[i];
        else
         throw std::out_of_range("case vide");
       }

      ////////////////////////////////////////
      //
      // operator read/write
      //
      // Ici, le problème, c'est que le langage
      // ne permet pas de savoir si c'est en lecture
      // non-const ou en écriture!
      //
      T & operator[](size_t i)
       {
        if (bitmap[i]==false)
         {
          nb_items++;
          bitmap[i]=true;
          new (array+i) T(0); // placement new + default constructor
         }

        return array[i];
       }

      ////////////////////////////////////////
      //
      // libère la case i
      //
      void free(size_t i)
       {
        if (bitmap[i])
         {
          bitmap[i]=false;
          array[i].~T(); // dtor explicite
          nb_items--;
         }
        else
         throw std::out_of_range("pas d'items dans cette case!");
       }

      ///////////////////////////////////////
      //
      // insère à i
      //
      void insert(size_t i, const T & v)
       {
        // si i est occupé
        if (bitmap[i])
         {
          // ...et qu'on peut tasser
          size_t r;
          if (zero_right(i,r))
           shift_right(i,r);
          else
           // un item tomberait en bas!
           throw std::out_of_range("tableau plein (à droite)!");

          array[i].~T(); // détruit l'ancien objet, s'il existe
         }

        bitmap[i]=true;
        new (array+i) T(v); // placement new + copy constructor
        nb_items++;
       }

      ////////////////////////////////////////
      //
      // supprime à i (si on ne déplace rien,
      // c'est free(i)
      //
      void remove(size_t i) { free(i); }

      size_t nb() const { return nb_items; }
      size_t size() const { return capacity; }

  paresse(size_t n)
   : capacity(n),
     nb_items(0),
     bitmap(n) // réserve n bits
  {
   // ici, bitmap est initialisé à zéro
   // mais on doit créer array, qui n'est
   // qu'une plage de mémoire pour court-
   // circuiter les constructeurs
   //
   array=(T*)new char[ sizeof(T)* n];
  }

  ~paresse()
   {
    for (size_t i=0;i<capacity;i++)
     if (bitmap[i])
      array[i].~T();

    delete[] array; // libère la mémoire sans (r)appler les destructeurs
   }
 };


#endif
 // __MODULE_PARESSE__
