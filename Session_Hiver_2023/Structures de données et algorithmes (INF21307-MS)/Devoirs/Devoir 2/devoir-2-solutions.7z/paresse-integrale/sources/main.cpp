#include <iostream>

#include <paresse.hpp>

////////////////////////////////////////
template <typename T>
void show(const paresse<T> & v)
 {
  for (size_t i=0;i<v.size();i++)
   {
    if (v.is_occupied(i))
     std::cout << v[i];
    else
     std::cout << "✖"; // u+2716
    if (i<v.size()-1)
     std::cout << ",";
   }

  std::cout << std::endl;
 }

////////////////////////////////////////
int main(int argc, const char * argv[])
 {
  paresse<int> paresseux(20);

  paresseux[3]=4;
  paresseux[5]=6;

  show(paresseux);

  paresseux.insert(3,5); show(paresseux);
  paresseux.insert(3,7); show(paresseux);
  paresseux.remove(4);   show(paresseux);

  return 0;
 }
