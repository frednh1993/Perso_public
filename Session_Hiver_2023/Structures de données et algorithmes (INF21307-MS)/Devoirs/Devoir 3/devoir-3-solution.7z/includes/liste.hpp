#ifndef __MODULE_LISTE_PARESSEUSE__
#define __MODULE_LISTE_PARESSEUSE__

#include <stdexcept>
#include <iostream>

////////////////////////////////////////
//
// classe qui sert de base pour les nœuds
// et la sentinelle=classe
//
class links
  {
   public:

       links *prev, *next;

   links(links *p=nullptr, links *n=nullptr)
    : prev(p),next(n)
   {}

   ~links()=default; // rien à faire.
  };

////////////////////////////////////////
//
// classe nœud
// 
template <typename T>
class node : public links
 {
  public:

      T item;

      const T & get_item() const { return item; }
      void set_item(const T & t) { item=t; }

      node<T> * get_next() const { return (node<T>*)next; }
      node<T> * get_prev() const { return (node<T>*)prev; }


  node(const T & t, node *p=nullptr, node *n=nullptr)
   : links(p,n),item(t)
   {}

  ~node()=default; // pas oublié, mais on appelle le dtor de T
};

////////////////////////////////////////
template <typename T>
class liste: protected links
 {
  protected:

      //  hérités de links:
      //  prev, qui est la queue
      //  next, qui est la tête

      size_t nb_items; // combien d'éléments dans la liste

  public:

  ////////////////////////////////////////
  size_t size() const { return nb_items; }

  ////////////////////////////////////////
  //
  // version assez crue des itérateurs
  //
  // le transtypage ("cast") est nécessaire
  // parce que les pointeurs de links
  // ne sont pas des pointeurs de nodes
  //
  // (idéalement on aurait une classe de plus
  // qui encapsule les itérateurs)
  //
  const node<T> * cend()   const { return (node<T>*)this; }
  const node<T> * cbegin() const { return (node<T>*)this->next; }
  node<T> * end()   { return (node<T>*)this; }
  node<T> * begin() { return (node<T>*)this->next; }

  ////////////////////////////////////////
  node<T> * search(const T & t)
   {
    node<T> * p=begin();

    while (p!=end() && (p->get_item()!=t))
     p=(node<T>*)p->next;

    return p;
   }

  ////////////////////////////////////////
  void erase(node<T> *p)
   {
    if (p!=end())
     {
      p->prev->next=p->next;
      p->next->prev=p->prev;
      delete p; // dtor de nœud + dtor de T

      nb_items--;
     }
    else
     throw std::runtime_error("cannot delete end()");    
   }

  ////////////////////////////////////////
  //
  // insert juste avant
  //
  // insert(begin(),t) au debut
  // insert(end(),t) a la fin
  //
  void insert(node<T> * p, const T & t)
   {
    // on utilise le constructeur
    // pour assiner les pointeurs
    // du nouveau nœud.
    node<T> * n = new node<T>(t, (node<T>*)p->prev, (node<T>*)p);

    p->prev->next=n;
    p->prev=n;

    nb_items++;
   }


  liste()
   : links(this,this),nb_items(0)
   {}

  ////////////////////////////////////////
  //
  // pour effacer la liste, on efface le
  // premier élément, tant qu'il y en a un.
  //
  ~liste()
   {
    while (this->next!=(node<T>*)this)
     erase((node<T>*)this->next);
   }
};

#endif
     // __MODULE_LISTE_PARESSEUSE__
