#include <iostream>

#include <liste.hpp>

////////////////////////////////////////
//
// Ne devrait pas faire partie de la liste
// normalement, ça devrait être une fonction
// externe, comme ici
//
// On respecte aussi la const-itude.
//
template <typename T>
void show(const liste<T> & l)
{
  const node<T> * p=l.cbegin();
  
  std::cout << "[";
  
  // tant qu'on ne revient pas
  // sur la sentinelle...
  while ( p!=l.cend() )
   {
    std::cout << " " << p->get_item();
    
    p=p->get_next();
   }
  
  std::cout << " ]" << std::endl;
}


////////////////////////////////////////
int main() //int argc, char * argv[])
 {
  liste<int> cossin;

  show(cossin);

  for (int c: {1,2,3,4})
   {
    cossin.insert(cossin.begin(),c);
    show(cossin);
   }

  // pas super pertinent, vu que...
  // on ne sait pas trop où sont les
  // nœuds en mémoire
  std::cout << cossin.search(3) << std::endl;
  std::cout << cossin.search(83) << std::endl;
  std::cout << cossin.end() << std::endl;
  std::cout << &cossin << std::endl;

  cossin.erase(cossin.search(3));
  show(cossin);
  cossin.insert(cossin.begin(),5);
  cossin.insert(cossin.search(2),7);
  cossin.insert(cossin.end(),8);
  show(cossin);
  cossin.erase(cossin.search(5));
  show(cossin);

  // test iterateurs-ish.
  const node<int> * p=cossin.cbegin();

  while (p!=cossin.cend())
   {
    std::cout << p->get_item() << std::endl;
    p=p->get_next();
   }

  for (int c: { 2,5,6,8} )
   cossin.insert(cossin.end(),c);
  show(cossin);

  cossin.erase(cossin.search(2));
  cossin.erase(cossin.search(5));
  cossin.erase(cossin.search(8));
  show(cossin);


  return 0;
 }
