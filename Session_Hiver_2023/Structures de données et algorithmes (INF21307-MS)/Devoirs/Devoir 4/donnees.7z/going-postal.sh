#!/usr/bin/env bash

for a in {A..Z}
do
    for b in {0..9}
    do
        for c in {A..Z}
        do
            for d in {0..9}
            do
                for e in {A..Z}
                do
                    for f in {0..9}
                    do
                        echo $a$b$c $d$e$f
                    done
                done
            done
        done
    done
done
