#!/usr/bin/env bash

# 10000 lignes
# de 1-70 caractères random

symbols=( {A..Z} {a..z} {0..9} \! @ \# \$ % ^ \& \( \)  \* { [ ] } \| )
nb_symbols=${#symbols[@]}

for ((i=0;i<10000;i++))
do
    length=$((1+($RANDOM % 70) ))
    for ((l=0;l<length;l++))
    do
        echo -n "${symbols[ $RANDOM % $nb_symbols ]}"
    done
    echo
done
