from kafka import KafkaConsumer, KafkaProducer
import mysql.connector
from mysql.connector import Error
import json
from json import JSONDecodeError

class kafka_custom_service():
    def __init__(self):
        self.bootstrap_servers = [
                    "kafka-0.kafka.default.svc.cluster.local:9092",
                    "kafka-1.kafka.default.svc.cluster.local:9092",
                    "kafka-2.kafka.default.svc.cluster.local:9092"
                ]
        self.topic_users = 'users'
        self.topic_notification = 'notification'
        self.consumer = KafkaConsumer(self.topic_users,group_id='test-python', bootstrap_servers=self.bootstrap_servers)
        self.producer = KafkaProducer(bootstrap_servers=self.bootstrap_servers)
        self.control_message = ("%%BEGIN%%","%%END%%")
        self.cnx = mysql.connector.connect(user='root', password='pass',
                                    host='mysql',
                                    database='uqar')
        self.cursor = self.cnx.cursor(dictionary=True)
        self.etudiant_cache = dict()
        self.cache_warmer()

    def __del__(self):
        if self.cnx.is_connected():
                self.cnx.close()
                print("MySQL connection is closed")

    def start(self):
        for message in self.consumer:
            message = message.value.decode('utf-8')
            if message in self.control_message:
                self.producer.send(self.topic_notification,message.encode())
                continue
            try:
                json_message = json.loads(message)
            except JSONDecodeError as e:
                print("json format error in the message : ",e)
                continue
            print('Received message: {}'.format(json_message))
            email = self.get_etudiant(json_message)
            if email:
                data = dict(email=email)
                data_to_send = json.dumps(data)
                print(data_to_send)
                self.producer.send(self.topic_notification, data_to_send.encode())
    
    def get_etudiant_from_db(self, nom):
        try:            
            query = ("SELECT email FROM etudiants where nom=%s;")
            self.cursor.execute(query,(nom,))
            row = self.cursor.fetchone()
            return row['email']
        
        except Error as e:
            print("Error reading data from MySQL table", e)

    def cache_warmer(self):
        try:
            query = ("SELECT * FROM etudiants;")
            self.cursor.execute(query)
            rows = self.cursor.fetchall()
            for row in rows:
                nom = row['nom']
                email = row['email']
                self.etudiant_cache[nom] = email

        except Error as e:
            print("Error reading data from MySQL table", e)
    
    def get_etudiant(self, nom_json):
        nom = nom_json['nom']
        if nom not in self.etudiant_cache:
            self.etudiant_cache[nom] = self.get_etudiant_from_db(nom)
        
        return self.etudiant_cache[nom]

kafka_custom_service().start()