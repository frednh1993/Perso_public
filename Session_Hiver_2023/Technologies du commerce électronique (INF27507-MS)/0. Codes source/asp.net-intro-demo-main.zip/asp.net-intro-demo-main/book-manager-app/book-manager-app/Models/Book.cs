﻿namespace seance_04_exercice_01.Models
{
    public class Book
    {
        public string Title { get; set; } = "";
        public string Author { get; set; } = "";
        public string Editor { get; set; } = "";
        public string ImageCover { get; set; } = "";
    }
}
