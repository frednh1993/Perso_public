﻿namespace stripe_simple_example_app
{
    public class StripeSettings
    {
        public string? PublicKey { get; set; }
        public string? SecretKey { get; set; }
    }
}
