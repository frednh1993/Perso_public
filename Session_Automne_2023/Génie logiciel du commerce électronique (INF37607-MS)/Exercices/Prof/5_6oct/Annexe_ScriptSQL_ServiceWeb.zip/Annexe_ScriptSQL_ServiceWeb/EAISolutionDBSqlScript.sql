USE [master]
GO
CREATE DATABASE [EAISolutionDB]
GO
Use [EAISolutionDB]
GO
CREATE TABLE [dbo].[tblRequest](
	[ReqId] [varchar](50) NOT NULL,
	[OrderDate] [datetime] NOT NULL,
	[OrderTotal] [decimal](18, 2) NOT NULL,
	[Email] [varchar](50) NOT NULL,
 CONSTRAINT [PK_tblRequest] PRIMARY KEY CLUSTERED 
(
	[ReqId] ASC
)
) ON [PRIMARY]

GO

CREATE TABLE [dbo].[tblRequestItem](
	[ItemId] [varchar](50) NOT NULL,
	[Description] [varchar](50) NOT NULL,
	[Quantity] [int] NOT NULL,
	[UnitPrice] [decimal](18, 2) NOT NULL,
	[TotalPrice] [decimal](18, 2) NOT NULL,
	[ReqId] [varchar](50) NOT NULL,
 CONSTRAINT [PK_tblRequestItem_1] PRIMARY KEY CLUSTERED 
(
	[ItemId] ASC
)
) ON [PRIMARY]

GO
ALTER TABLE [dbo].[tblRequestItem]  WITH CHECK ADD  CONSTRAINT [FK_tblRequest_tblRequestItem] FOREIGN KEY([ReqId])
REFERENCES [dbo].[tblRequest] ([ReqId])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[tblRequestItem] CHECK CONSTRAINT [FK_tblRequest_tblRequestItem]
GO
