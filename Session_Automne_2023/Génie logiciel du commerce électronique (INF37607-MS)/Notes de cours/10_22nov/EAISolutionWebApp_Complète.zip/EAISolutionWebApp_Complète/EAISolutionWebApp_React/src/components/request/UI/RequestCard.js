import React from "react";

class RequestCard extends React.Component {
  render() {
    const { request, onSelect, onDelete, onSubmit } = this.props;

    return (
      <tr>
        <td>{request.id}</td>
        <td>{request.orderDate}</td>
        <td>{request.orderTotal}</td>
        <td>{request.isSubmitted ? "submitted" : "-"}</td>
        <td className="text-center _buttons">
          {!request.isSubmitted ? (
            <div>
              <button className="btn btn-primary selectButt" onClick={onSubmit}>
                Submit
              </button>
              <button className="btn btn-outline-danger" onClick={onDelete}>
                Delete
              </button>
            </div>
          ) : (
            ""
          )}
          <div>
            <button
              className="btn btn-success selectReqButt"
              onClick={onSelect}
            >
              Select
            </button>
          </div>
        </td>
      </tr>
    );
  }
}

export default RequestCard;
