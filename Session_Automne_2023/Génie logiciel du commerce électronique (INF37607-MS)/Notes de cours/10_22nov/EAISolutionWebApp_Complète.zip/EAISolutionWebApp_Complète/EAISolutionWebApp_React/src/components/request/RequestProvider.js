import React from "react";
import { inject } from "mobx-react";
import RequestController from "./RequestController";
import RequestViewModel from "./RequestViewModel";
import RootStore from "../../models/RootStore";

@inject(RootStore.type.REQUEST_MODEL)
class RequestProvider extends React.Component {
  constructor(props) {
    super(props);
    const requestModel = props[RootStore.type.REQUEST_MODEL];
    this.viewModel = new RequestViewModel(requestModel);
  }

  render() {
    return <RequestController viewModel={this.viewModel} />;
  }
}

export default RequestProvider;
