import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import "./App.css";
import { Provider } from "mobx-react";
import RequestProvider from "./components/request/RequestProvider";
import ItemProvider from "./components/item/ItemProvider";
import LoginProvider from "./components/login/LoginProvider";
import RootStore from "./models/RootStore";

const rootStore = new RootStore();

class App extends Component {
  render() {
    return (
      <Provider {...rootStore.getStores()}>
        <div>
          <Router>
            <Switch>
              <Route path="/" exact render={() => <LoginProvider />} />
              <Route path="/requests" render={() => <RequestProvider />} />
              <Route path="/items" render={() => <ItemProvider />} />
            </Switch>
          </Router>
        </div>
      </Provider>
    );
  }
}

export default App;
