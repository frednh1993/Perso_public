class RequestViewModel {
  constructor(store) {
    this.store = store["request"];
    this.userStore = store["user"];
    this.itemStore = store["item"];
  }

  async getRequests() {
    await this.store.getRequests();
  }

  async addRequest() {
    await this.store.addRequest();
  }

  async deleteRequest(request) {
    await this.store.deleteRequest(request);
  }

  async submitRequest(request) {
    await this.store.submitRequest(request);
  }
}

export default RequestViewModel;
