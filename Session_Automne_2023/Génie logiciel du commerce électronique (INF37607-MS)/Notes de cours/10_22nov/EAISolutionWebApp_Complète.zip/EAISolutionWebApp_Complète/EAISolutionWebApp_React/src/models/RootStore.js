import RequestModel from "./domain/RequestModel";
import ItemModel from "./domain/ItemModel";
import UserModel from "./domain/UserModel";

class RootStore {
  static type = {
    REQUEST_MODEL: "requestModel",
    USER_MODEL: "userModel",
    ITEM_MODEL: "itemModel",
  };

  constructor() {
    this.requestModel = new RequestModel();
    this.itemModel = new ItemModel();
    this.UserModel = new UserModel();
  }

  getStores = () => ({
    [RootStore.type.REQUEST_MODEL]: {
      request: this.requestModel,
      user: this.UserModel,
      item: this.itemModel,
    },
    [RootStore.type.ITEM_MODEL]: {
      item: this.itemModel,
      user: this.UserModel,
      request: this.requestModel,
    },
    [RootStore.type.USER_MODEL]: {
      user: this.UserModel,
      request: this.requestModel,
    },
  });
}

export default RootStore;
