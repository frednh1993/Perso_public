import React from "react";
import RequestList from "./UI/RequestList";
import Header from "../Header";

class RequestView extends React.Component {
  render() {
    const {
      requests,
      deleteRequest,
      submitRequest,
      getRequestItems,
      addRequest,
    } = this.props;

    return (
      <React.Fragment>
        <Header />
        <RequestList
          deleteRequest={deleteRequest}
          submitRequest={submitRequest}
          getRequestItems={getRequestItems}
          addRequest={addRequest}
          requests={requests}
        />
      </React.Fragment>
    );
  }
}

export default RequestView;
