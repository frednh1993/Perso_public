import React from "react";
import { observer } from "mobx-react";
import RequestCard from "./RequestCard";

const RequestList = observer(
  class RequestList extends React.Component {
    render() {
      return (
        <div>
          {this.props.requests.length ? (
            <div>
              <div className="container mylist">
                <div className="row">
                  <div className="col-12">
                    <label className="_lbl">My Requests </label>
                    <table className="table table-bordered">
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>Date</th>
                          <th>Total</th>
                          <th>State</th>
                          <th width="35%"></th>
                        </tr>
                      </thead>
                      <tbody>
                        {this.props.requests.map((request) => (
                          <RequestCard
                            key={request.id}
                            request={request}
                            onDelete={() => this.props.deleteRequest(request)}
                            onSubmit={() => this.props.submitRequest(request)}
                            onSelect={() => this.props.getRequestItems(request)}
                          />
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <h1 className="emptyList-msg">Create your first request..</h1>
          )}
          <div className="text-center">
            <button
              className="btn-lg btn-secondary btn-rounded mb-4 _dsn"
              onClick={this.props.addRequest}
            >
              New request
            </button>
          </div>
        </div>
      );
    }
  }
);
export default RequestList;
