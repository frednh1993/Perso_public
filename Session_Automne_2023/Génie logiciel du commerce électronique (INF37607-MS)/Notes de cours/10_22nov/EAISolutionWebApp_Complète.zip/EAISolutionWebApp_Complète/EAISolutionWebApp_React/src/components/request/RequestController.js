import React from "react";
import { Redirect } from "react-router";
import RequestView from "./RequestView";

class RequestController extends React.Component {
  state = {
    id: "",
    isSubmitted: "",
    orderDate: "",
    orderTotal: "",
    isSelected: false,
  };

  addRequest = async () => {
    await this.props.viewModel.addRequest();
  };

  deleteRequest = async (request) => {
    this.props.viewModel.deleteRequest(request);
  };

  submitRequest = async (request) => {
    await this.props.viewModel.submitRequest(request);
  };

  getRequests = async () => {
    await this.props.viewModel.getRequests();
  };

  getRequestItems = (request) => {
    localStorage.setItem("current_request", JSON.stringify(request));
    this.props.viewModel.itemStore.getItems(request.id);
    this.setState({ isSelected: true });
  };

  render() {
    const { viewModel } = this.props;
    if (!viewModel.userStore.getUser()) {
      return <Redirect to="/" />;
    } else if (this.state.isSelected) {
      return <Redirect to="/items" />;
    } else {
      //this.getRequests();
      return (
        <RequestView
          requests={viewModel.store.requests}
          addRequest={this.addRequest}
          deleteRequest={this.deleteRequest}
          submitRequest={this.submitRequest}
          getRequestItems={this.getRequestItems}
        />
      );
    }
  }
}

export default RequestController;
