﻿using System.Collections.Generic;
using System.Text;
using System.Linq;
using Xunit;
using Moq;
using EAISolutionFrontEnd.Core;
using EAISolutionFrontEnd.Core.Interfaces;
using EAISolutionFrontEnd.Core.Services;

namespace EAISolutionFrontEnd.TestsUnitaires.Core.Services
{
    public class AddRequest
    {

        private Mock<IUserRepository> _mockUserRepository;
        private Mock<IRequestRepository> _mockRequestRepository;

        public AddRequest()
        {
            _mockUserRepository = new Mock<IUserRepository>();
            _mockRequestRepository = new Mock<IRequestRepository>();
        }

        [Fact]
        public async void AjouterRequest()
        {
            // Première étape: configurer les mocks pour qu’ils retournent les bons objets

            User user = new User { Id = 1 };
            _mockUserRepository.Setup(x =>
                  x.GetByIdAsync(user.Id)).ReturnsAsync(user);
            Request request = new Request { Id = 1 };
            request.User = user;
            _mockRequestRepository.Setup(x => x.GetByIdAsync(request.Id)).ReturnsAsync(request);

            
            
            //Deuxième étape: appeler le service

            RequestService service = new RequestService(_mockRequestRepository.Object, null, null);
            await service.AddRequest(request);

            //Troisième étape: vérifier les appels aux repositories:

            _mockRequestRepository.Verify(x => x.AddAsync(request), Times.Once);
            _mockRequestRepository.VerifyNoOtherCalls();

            //Quatrième étape: vérifier la valeur finale

            Assert.Equal(1, request.User.Id);
            

        }

    }
}
