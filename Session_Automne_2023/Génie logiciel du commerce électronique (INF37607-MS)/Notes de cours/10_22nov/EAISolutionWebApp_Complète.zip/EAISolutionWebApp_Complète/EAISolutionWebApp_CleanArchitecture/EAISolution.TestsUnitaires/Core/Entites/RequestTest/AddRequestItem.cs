﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Xunit;
using EAISolutionFrontEnd.Core;

namespace EAISolutionFrontEnd.TestsUnitaires.Core.Entites.RequestTest
{
    public class AddRequestItem
    { 
        [Fact]
        public void AjouterRequestItem()
        {
            User user = new User("Ismail", "Khriss", "ismail+khriss@uqar.ca", "Toto");
            Request request = new Request(user);
            request.AddRequestItem(new RequestItem("Article pas cher", 10, 2.0M));
            Assert.Single(request.RequestItems);
        }

        [Theory]
        [InlineData("Article pas cher", 10, 2, "Article cher", 1, 1000, 1020)]
        [InlineData("Article  cher", 2, 500, "Article cher", 1, 2000, 3000)]

        public void OrderTotal(string item1, int quantity1, decimal price1, string item2, int quantity2, decimal price2, decimal exptectedTotal)
        {
            User user = new User("Ismail", "Khriss", "ismail+khriss@uqar.ca", "Toto");
            Request request = new Request(user);
            request.AddRequestItem(new RequestItem(item1, quantity1, price1));
            request.AddRequestItem(new RequestItem(item2, quantity2, price2));
            Assert.Equal(request.OrderTotal(), exptectedTotal);
        }


    }
}
