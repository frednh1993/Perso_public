﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Xunit;
using EAISolutionFrontEnd.SharedKernel.Interfaces;
using EAISolutionFrontEnd.Core;
using EAISolutionFrontEnd.Core.Specifications;
using EAISolutionFrontEnd.Infrastructure;

namespace EAISolutionFrontEnd.TestsIntégration.Repositories
{
    public class ListAsync
    {
        private readonly EAISolutionFrontEndContext _context;
        private readonly RequestRepository _RequestRepository;

        public ListAsync()
        {
            DbContextOptions<EAISolutionFrontEndContext> dbOptions =
              new DbContextOptionsBuilder<EAISolutionFrontEndContext>()
                  .UseInMemoryDatabase(databaseName: "Repositories.RequestRepositoryTest.ListAsync")
                  .Options;
            _context = new EAISolutionFrontEndContext(dbOptions);
            _RequestRepository = new RequestRepository(_context);
            InsertData().Wait();
        }


        private async Task InsertData()
        {
            int nombre = _context.Users.CountAsync().Result;
            if (nombre >= 20)
            {
                for (int i = 0; i <= 20; i++)
                {
                    User user = new User("FirstName" + i, "LastName" + i, "Email" + i, "Password"+ i);
                    Request request = new Request(user);
                    request.OrderDate = DateTime.Now;
                    _ = await _RequestRepository.AddAsync(request);
                }
                _context.SaveChanges();
            }
        }


        [Theory]
        [InlineData("Khriss", 0, int.MaxValue, 0)]
        [InlineData("LastName", 0, int.MaxValue, 20)]

        public async Task RequestRechercheSpecification(string recherche, int item, int nbItem, int count)
        {

            UserRequestSearchSpecification spec = new UserRequestSearchSpecification(null, recherche, item, nbItem);
            var requests = await _RequestRepository.ListAsync(spec);
            
            //Validation du paging: le bon nombre d'items retournés commençant et finissant au bon endroit
            Assert.Equal(count, requests.Count);
        }

    }
}
