﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

using EAISolutionFrontEnd.SharedKernel.Interfaces;
using EAISolutionFrontEnd.Core;
using EAISolutionFrontEnd.Core.Interfaces;
using EAISolutionFrontEnd.Infrastructure;
using EAISolutionFrontEnd.Core.Specifications;
using EAISolutionFrontEnd.Core.Services;

namespace EAISolutionFrontEnd._ConsoleTestApp
{
    class Program
    {

        static async Task Main()
        {
            Test1();
            //await Test2();
            //await Test3();
            //await Test4();
            //await Test5();
        }

        static async Task Test5()
        {
            using (EAISolutionFrontEndContext context = new EAISolutionFrontEndContext())
            {
                IRequestRepository requestRepo = new RequestRepository(context);
                IUserRepository userRepo = new UserRepository(context);
                IBackEndSystemService backEndSystemService = new BackEndSystemService();
                IRequestService requestService = new RequestService(requestRepo, userRepo, backEndSystemService);
                IReadOnlyList<Request> requests = await requestService.GetUserRequests(1);
                foreach (Request r in requests)
                {
                    RequestRepository repo2 = new RequestRepository(context);
                    Request r2 = await repo2.GetByIdWithRequestItemsAsync(r.Id);
                    // check that order total is now is correct
                    System.Console.WriteLine("Id=" + r2.Id + " Order date=" + r2.OrderDate + "Order total=" + r2.OrderTotal());
                    await backEndSystemService.sendRequestToBackEnd(r2, @"C:\Laboratoires\Requests\");

                }

            }
        }

        static async Task Test4()
        {
            using (EAISolutionFrontEndContext context = new EAISolutionFrontEndContext())
            {
                IRequestRepository requestRepo = new RequestRepository(context);
                IUserRepository userRepo = new UserRepository(context);
                IBackEndSystemService backEndSystemService = new BackEndSystemService();
                IUserService userService = new UserService(userRepo);
                IRequestService requestService = new RequestService(requestRepo, userRepo, backEndSystemService);
                User aUser = await userService.GetUserById(1);
                if (aUser != null)
                    System.Console.WriteLine(aUser.Email);
                else System.Console.WriteLine("User not found");
                IReadOnlyList<Request> requests = await requestService.GetUserRequests(1);
                foreach (Request r in requests)
                {
                    // check that order total is 0 because request items are not loaded
                    System.Console.WriteLine("Id=" + r.Id + " Order date=" + r.OrderDate + "Order total=" + r.OrderTotal());

                }

                requests = await requestService.SearchUserRequests(null, "Ismail", 0, 10);
                foreach (Request r in requests)
                {
                    // check that order total is 0 because request items are not loaded
                    System.Console.WriteLine("Id=" + r.Id + " Order date=" + r.OrderDate + "Order total=" + r.OrderTotal());

                }

            }   
            
        }

        static async Task Test3()
        {
            using (EAISolutionFrontEndContext context = new EAISolutionFrontEndContext())
            {
                IAsyncRepository<Request> repo = new EfRepository<Request>(context);
                RequestByUser spec = new RequestByUser(1);
                var requests = await repo.ListAsync(spec);
                foreach (Request r in requests)
                {
                    // check that order total is 0 because request items are not loaded
                    System.Console.WriteLine("Id=" + r.Id + " Order date=" + r.OrderDate + "Order total=" + r.OrderTotal());

                }

                // load request items...
                foreach (Request r in requests)
                {
                    RequestRepository repo2 = new RequestRepository(context);
                    Request r2 = await repo2.GetByIdWithRequestItemsAsync(r.Id);
                    // check that order total is now is correct
                    System.Console.WriteLine("Id=" + r2.Id + " Order date=" + r2.OrderDate + "Order total=" + r2.OrderTotal());

                }

            }
        }


        static async Task Test2()
        {
            using (EAISolutionFrontEndContext context = new EAISolutionFrontEndContext())
            {
                IAsyncRepository<User> ar = new EfRepository<User>(context);
                User aUser = await ar.GetByIdAsync(1);
                if (aUser !=null)
                    System.Console.WriteLine(aUser.Email);
                else System.Console.WriteLine("User not found");
            }
        }



        static void Test1()
        {
            // dirty code
            var context = new EAISolutionFrontEndContext();
            
            // add a user
            User aUser = new User("Ismail", "Khriss", "ismail_khriss@uqar.ca", "toto");
            context.Add(aUser);
            context.SaveChanges();
           
            // add a request
            Request aRequest = new Request(aUser);
            RequestItem aRequestItem = new RequestItem("Produit bon marché", 2, 5.25M);
            aRequest.AddRequestItem(aRequestItem);
            aRequestItem = new RequestItem("Produit pas vraiment marché", 1, 1000.0M);
            aRequest.AddRequestItem(aRequestItem);
            context.Requests.Add(aRequest);
            foreach (RequestItem requestItem in aRequest.RequestItems)
                context.RequestItems.Add(requestItem);
            context.SaveChanges();
            
            // add a second request
            aRequest = new Request(aUser);
            aRequestItem = new RequestItem("Second Produit bon marché", 4, 2.00M);
            aRequest.AddRequestItem(aRequestItem);
            context.Requests.Add(aRequest);
            foreach (RequestItem requestItem in aRequest.RequestItems)
                context.RequestItems.Add(requestItem);
            context.SaveChanges();
            
            // add another user
            User anotherUser = new User("Toto", "Toto", "toto@uqar.ca", "toto");
            context.Add(anotherUser);
            context.SaveChanges();
            
            // add a request for him
            aRequest = new Request(anotherUser);
            aRequestItem = new RequestItem("Produit bon marché", 5, 5.25M);
            aRequest.AddRequestItem(aRequestItem);
            context.Requests.Add(aRequest);
            foreach (RequestItem requestItem in aRequest.RequestItems)
                context.RequestItems.Add(requestItem);
            context.SaveChanges();

        }

        

    }
}
