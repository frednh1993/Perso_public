﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EAISolutionFrontEnd.SharedKernel.Interfaces
{
    public interface IAggregateRoot
    {
    }
}
