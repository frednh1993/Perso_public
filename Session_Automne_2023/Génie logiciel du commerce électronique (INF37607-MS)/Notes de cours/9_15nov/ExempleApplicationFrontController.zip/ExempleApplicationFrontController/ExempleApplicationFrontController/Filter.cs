﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExempleApplicationFrontController
{
    public class Filter : IHttpModule
    {
        #region IHttpModule Members

        void IHttpModule.Dispose()
        {

        }

        void IHttpModule.Init(HttpApplication context)
        {
            context.BeginRequest += new EventHandler(context_BeginRequest);
            context.AuthenticateRequest += new EventHandler(OnAuthentication);
        }

        #endregion

        void context_BeginRequest(object sender, EventArgs eventArgs)
        {
            string lAdresseUrlRelative = HttpContext.Current.Request.FilePath;
            DateTime lDate = System.DateTime.Now;
            string lActionCommande = HttpContext.Current.Request.QueryString["command"];
            string lAdresseIP = HttpContext.Current.Request.UserHostAddress;
            string lAdresseUrlAbsolue = HttpContext.Current.Request.RawUrl;
        }
        void OnAuthentication(object sender, EventArgs a)
        {
            string lAdresseUrlRelative = HttpContext.Current.Request.FilePath;
            if (lAdresseUrlRelative.EndsWith(".js") || lAdresseUrlRelative.EndsWith(".css") || lAdresseUrlRelative.EndsWith(".gif") || lAdresseUrlRelative.EndsWith(".png") || lAdresseUrlRelative.EndsWith(".ico")
                || lAdresseUrlRelative.StartsWith("/WebRessource.axd") || lAdresseUrlRelative.StartsWith("/ScriptRessource.axd")) return;
            HttpApplication application = (HttpApplication)sender;
            HttpContext context = application.Context;

            //RequeteAccesPage lRequeteAccesPage = new RequeteAccesPage();
            //lRequeteAccesPage.Date = System.DateTime.Now;
            //lRequeteAccesPage.ActionCommande = HttpContext.Current.Request.QueryString["command"];
            //lRequeteAccesPage.AdresseIP = HttpContext.Current.Request.UserHostAddress;
            //lRequeteAccesPage.AdresseUrlAbsolue = HttpContext.Current.Request.RawUrl;
            //lRequeteAccesPage.EstAuthentifie = HttpContext.Current.Request.IsAuthenticated;
            //lRequeteAccesPage.EstConnexionSecure = HttpContext.Current.Request.IsSecureConnection;
            //lRequeteAccesPage.EstLocal = HttpContext.Current.Request.IsLocal;
            //lRequeteAccesPage.AdresseUrlRelative = HttpContext.Current.Request.FilePath;
            //lRequeteAccesPage.IdAnnonyme = HttpContext.Current.Request.AnonymousID;
            //IPrincipal user = application.Context.User;
            //FormsIdentity identity = null;
            //String idUsager = "";
            //if (application.Context.User != null)
            //{
            //    identity = (FormsIdentity)user.Identity;
            //    idUsager = Util.Decrypt(identity.Name);
            //    Guid guidUsager = new Guid(idUsager);
            //    CompteMapper lCompteMapper = (CompteMapper)DALFactory.GetDALFactory().GetCompteMapper();
            //    Compte lCompte = lCompteMapper.Find(guidUsager);
            //    if (lCompte != null) idUsager = lCompte.Nom;

            //}
            //lRequeteAccesPage.NomCompte = idUsager;
            //RequeteAccesPageMapper lRequeteAccespageMapper = (RequeteAccesPageMapper)DALFactory.GetDALFactory().GetRequeteAccesPageMapper();
            //lRequeteAccespageMapper.Insert(lRequeteAccesPage);
        }
    }
}
