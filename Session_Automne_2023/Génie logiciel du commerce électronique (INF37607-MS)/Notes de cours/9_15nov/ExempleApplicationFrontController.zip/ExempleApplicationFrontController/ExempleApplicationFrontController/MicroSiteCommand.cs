﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExempleApplicationFrontController
{
    public class MicroSiteCommand : FrontCommand
    {
        public override void Process()
        {

            //Redirige vers MicroSite.aspx
            context.Server.Transfer(
         System.Configuration.ConfigurationManager.AppSettings["MicroSiteUrl"], true);
        }
    }
}