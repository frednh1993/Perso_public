﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExempleApplicationFrontController
{
    public class MacroSiteCommand : FrontCommand
    {
        public override void Process()
        {

            //Redirige vers MacroSite.aspx
            context.Server.Transfer(
              System.Configuration.ConfigurationManager.AppSettings["MacroSiteUrl"], true);
        }
    }
}