﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExempleApplicationFrontController
{
    public class UnknownCommand : FrontCommand
    {

        public override void Process()
        {
            context.Response.ContentType = "text/plain";
            context.Response.Write("Front Controller commande inexistante");
        }
    }
}