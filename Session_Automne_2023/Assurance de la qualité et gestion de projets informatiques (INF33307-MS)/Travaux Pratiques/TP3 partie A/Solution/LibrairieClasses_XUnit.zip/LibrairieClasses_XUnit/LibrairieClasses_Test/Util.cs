﻿using System;

namespace LibrairieClasses_Test
{
    public class Util
    {
        public static void tri_a_bulle(ref int[] t, int n) {
            int tmp = 0;
            bool en_desordre = true;
            while (en_desordre) {
                en_desordre = false;
                for (int j = 0; j < n - 1; j++) {
                    if (t[j] > t[j+1]) {
                        tmp = t[j+1];
                        t[j + 1] = t[j];
                        t[j] = tmp;
                        en_desordre = true;
                    }
                }
            }
        }
    }
}

