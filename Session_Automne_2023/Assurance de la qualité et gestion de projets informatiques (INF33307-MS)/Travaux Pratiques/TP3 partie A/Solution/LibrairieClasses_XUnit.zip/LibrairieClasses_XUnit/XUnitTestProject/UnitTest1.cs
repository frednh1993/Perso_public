using System;
using Xunit;

using LibrairieClasses_Test;
using System.ComponentModel;

namespace XUnitTestTP3
{
    public class UnitTest1
    {
        [Fact]
        [Description("Test avec un tableau vide")]
        public void TestChemin2() {
            // chemin 2: 2-7, 8, 9-11, 12, 25, 8, 26.
            int[] tableau = new int[0] {};
            Util.tri_a_bulle(ref tableau, tableau.Length);
            int[] tableauAttendu = new int[0] {};
            Assert.Equal(tableauAttendu, tableau);
        }

        [Fact]
        [Description("Test avec un tableau tri�")]
        public void TestChemin3() {
            // chemin 3: 2-7, 8, 9-11, 12, 13-15, 24, 12, 25, 8, 26.
            int[] tableau = new int[2] { 1, 2 };
            Util.tri_a_bulle(ref tableau, tableau.Length);
            int[] tableauAttendu = new int[2] { 1, 2 };
            Assert.Equal(tableauAttendu, tableau);
        }

        [Fact]
        [Description("Test avec un tableau non tri�")]
        public void TestChemin4() {
            // chemin 4: 2-7, 8, 9-11, 12, 13-15, 16-23, 24, 12, 25, 8, 26.
            // Ce test fait le chemin suivant qui couvre le chemin 4
            // 2-7, 8, 9-11, 12, 13-15, 16-23, 24, 12, 25, 8, 9-11, 12, 13-15, 24, 12, 25, 8, 26
            int[] tableau = new int[2] { 2, 1 };
            Util.tri_a_bulle(ref tableau, tableau.Length);
            int[] tableauAttendu = new int[2] { 1, 2 };
            Assert.Equal(tableauAttendu, tableau);
        }

    }
}
