﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;

namespace temperature_conversion_app.Models
{
    public class User 
    {
        public string Name { get; set; }
    }
}
