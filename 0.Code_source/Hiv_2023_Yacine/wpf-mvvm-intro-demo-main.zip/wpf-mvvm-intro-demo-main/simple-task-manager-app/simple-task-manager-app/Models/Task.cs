﻿namespace simple_task_manager_app.Models
{
    class Task
    {
        public int TaskId { get; set; }
        public string Title { get; set; }
        public string Priority { get; set; }
        public string Status { get; set; }
    }
}
