# entity-framework-intro-demo
A complete example (Task manager) with Entity Framework
